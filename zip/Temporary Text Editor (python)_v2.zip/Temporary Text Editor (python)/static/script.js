function runCode() {
    var code = document.getElementById('code').value.trim();
    var output = document.getElementById('output');
    var error = document.getElementById('error');
    var loading = document.getElementById('loading');
    var runButton = document.getElementById('runButton');

    // Clear previous output and error messages
    output.innerHTML = '';
    error.innerHTML = '';

    // Disable the run button and show loading spinner
    runButton.disabled = true;
    loading.style.display = 'inline-block';

    // Simulate running code (replace with actual fetch API call)
    setTimeout(function() {
        if (code.length > 0) {
            // Replace this with actual fetch API call to server
            fetch('/run', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'code=' + encodeURIComponent(code),
            })
            .then(response => response.json())
            .then(data => {
                output.innerHTML = "Output:<br>" + data.output;
                error.innerHTML = data.error;
                if (data.error !== '') {
                    error.classList.add('show');
                } else {
                    error.classList.remove('show');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                error.innerHTML = 'Error communicating with the server.';
                error.classList.add('show');
            })
            .finally(() => {
                // Enable the run button and hide loading spinner
                runButton.disabled = false;
                loading.style.display = 'none';
            });
        } else {
            error.innerHTML = 'Error: No code entered.';
            error.classList.add('show');
            // Enable the run button and hide loading spinner
            runButton.disabled = false;
            loading.style.display = 'none';
        }
    }, 1000); // Simulate 1 second execution time
}