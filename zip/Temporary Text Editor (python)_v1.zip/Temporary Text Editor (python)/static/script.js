function runCode() {
    var code = document.getElementById('code').value;

    // Disable the run button and show loading spinner
    var runButton = document.getElementById('runButton');
    runButton.disabled = true;
    document.getElementById('loading').style.display = 'inline-block';

    fetch('/run', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'code=' + encodeURIComponent(code),
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('output').innerText = data.output;
        document.getElementById('error').innerText = data.error;
        if (data.error !== '') {
            document.getElementById('error').classList.add('show');
        } else {
            document.getElementById('error').classList.remove('show');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('error').innerText = 'Error communicating with the server.';
        document.getElementById('error').classList.add('show');
    })
    .finally(() => {
        // Enable the run button and hide loading spinner
        runButton.disabled = false;
        document.getElementById('loading').style.display = 'none';
    });
}
