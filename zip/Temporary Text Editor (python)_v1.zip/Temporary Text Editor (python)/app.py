from flask import Flask, render_template, request, jsonify
import subprocess
import webbrowser
import socket

app = Flask(__name__)

# Function to install dependencies from requirements.txt
def install_dependencies():
    subprocess.run(['pip', 'install', '-r', 'requirements.txt'], check=True)

# Install dependencies on startup
install_dependencies()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run', methods=['POST'])
def run_code():
    code = request.form['code']

    # Write the code to a temporary file
    with open('temp.py', 'w') as f:
        f.write(code)

    try:
        # Execute the code and capture output and errors
        result = subprocess.run(['python', 'temp.py'], capture_output=True, text=True, timeout=5)
        output = result.stdout
        error = result.stderr
        if result.returncode != 0:
            raise subprocess.CalledProcessError(result.returncode, 'python', output=output, stderr=error)
    except subprocess.CalledProcessError as e:
        error = e.stderr if e.stderr else str(e)
        return jsonify({'output': '', 'error': error})
    except subprocess.TimeoutExpired:
        error = "Execution timed out (5 seconds)"
        return jsonify({'output': '', 'error': error})
    except Exception as e:
        error = str(e)
        return jsonify({'output': '', 'error': error})

    return jsonify({'output': output, 'error': ''})

def get_local_ip():
    # Get the local IP address of the running device
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))  # Try to connect to a nonexistent IP
        local_ip = s.getsockname()[0]
    except:
        local_ip = '127.0.0.1'
    finally:
        s.close()
    return local_ip

if __name__ == '__main__':
    # Determine the IP address and construct the URL
    host_ip = get_local_ip()

    # Open the browser with the URL
    # Run the Flask app
    app.run(host='0.0.0.0', port=7777, debug=True)
