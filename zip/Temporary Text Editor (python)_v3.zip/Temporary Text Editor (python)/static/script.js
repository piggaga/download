document.addEventListener("DOMContentLoaded", function() {
    var codeTextarea = document.getElementById('code');
    var editor = CodeMirror.fromTextArea(codeTextarea, {
        mode: "python",
        theme: "default",
        lineNumbers: true,
    });

    // Open or create IndexedDB database
    var db;
    var request = window.indexedDB.open("CodeHistoryDB", 1);

    request.onerror = function(event) {
        console.error("IndexedDB error:", event.target.errorCode);
    };

    request.onupgradeneeded = function(event) {
        db = event.target.result;
        var objectStore = db.createObjectStore("history", { keyPath: "timestamp" });
        objectStore.createIndex("code", "code", { unique: false });
        objectStore.createIndex("output", "output", { unique: false });
        objectStore.createIndex("error", "error", { unique: false });
    };

    request.onsuccess = function(event) {
        db = event.target.result;
        console.log("IndexedDB successfully opened.");

        // Fetch and display history
        fetchHistory();
    };

    function fetchHistory() {
        var transaction = db.transaction(["history"], "readonly");
        var objectStore = transaction.objectStore("history");
        var historyDiv = document.getElementById('history');
        historyDiv.innerHTML = '';

        objectStore.openCursor().onsuccess = function(event) {
            var cursor = event.target.result;
            if (cursor) {
                var historyEntry = document.createElement('div');
                historyEntry.classList.add('history-entry');

                var codePre = document.createElement('pre');
                codePre.textContent = cursor.value.code;

                var outputPre = document.createElement('pre');
                outputPre.textContent = "Output:\n" + cursor.value.output;

                var errorPre = document.createElement('pre');
                errorPre.textContent = "Error:\n" + cursor.value.error;

                historyEntry.appendChild(document.createElement('hr'));
                historyEntry.appendChild(codePre);
                historyEntry.appendChild(outputPre);
                historyEntry.appendChild(errorPre);

                historyDiv.appendChild(historyEntry);

                cursor.continue();
            }
        };
    }

    window.runCode = function() {
        var code = editor.getValue().trim();
        var output = document.getElementById('output');
        var error = document.getElementById('error');
        var loading = document.getElementById('loading');
        var runButton = document.getElementById('runButton');

        // Clear previous output and error messages
        output.innerHTML = '';
        error.innerHTML = '';

        // Disable the run button and show loading spinner
        runButton.disabled = true;
        loading.style.display = 'inline-block';

        if (code.length > 0) {
            fetch('/run', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'code=' + encodeURIComponent(code),
            })
            .then(response => response.json())
            .then(data => {
                output.innerHTML = "Output:\n" + data.output;
                error.innerHTML = data.error;
                if (data.error !== '') {
                    error.classList.add('show');
                } else {
                    error.classList.remove('show');
                }

                // Save to IndexedDB history
                saveToHistory(code, data.output, data.error);
            })
            .catch(error => {
                console.error('Error:', error);
                error.innerHTML = 'Error communicating with the server.';
                error.classList.add('show');

                // Save to IndexedDB history even if there's an error
                saveToHistory(code, '', error.innerHTML);
            })
            .finally(() => {
                // Enable the run button and hide loading spinner
                runButton.disabled = false;
                loading.style.display = 'none';

                // Fetch and display updated history
                fetchHistory();
            });
        } else {
            error.innerHTML = 'Error: No code entered.';
            error.classList.add('show');
            // Enable the run button and hide loading spinner
            runButton.disabled = false;
            loading.style.display = 'none';
        }
    }

    function saveToHistory(code, output, error) {
        var timestamp = new Date().getTime();
        var transaction = db.transaction(["history"], "readwrite");
        var objectStore = transaction.objectStore("history");
        var historyEntry = { timestamp: timestamp, code: code, output: output, error: error };

        var request = objectStore.add(historyEntry);
        request.onsuccess = function(event) {
            console.log("History entry added to IndexedDB.");
        };

        request.onerror = function(event) {
            console.error("Error adding history entry to IndexedDB:", event.target.error);
        };
    }
});
document.addEventListener('keydown', function(event) {
    if (event.ctrlKey && event.key === 'Enter') {
        runCode();
    }
});


document.getElementById('code').addEventListener('keydown', function(event) {
    if (event.key === 'Tab') {
        event.preventDefault();
        var cursorPosition = this.selectionStart;
        var textBeforeCursor = this.value.substring(0, cursorPosition);
        var textAfterCursor = this.value.substring(cursorPosition, this.value.length);
        this.value = textBeforeCursor + '    ' + textAfterCursor;
        this.selectionStart = cursorPosition + 4;
        this.selectionEnd = cursorPosition + 4;
    }
});