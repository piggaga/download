import os
import time

# 獲取當前目錄
current_directory = os.getcwd()

# 創建.bat文件的內容
bat_content = f"cd {current_directory}\npip install -r requirements.txt\npython app.py"

# 定義.bat文件的名稱
bat_file_path = os.path.join(current_directory, "點擊這個運行.bat")

# 創建並寫入.bat文件
with open(bat_file_path, 'w') as bat_file:
    bat_file.write(bat_content)

print(f"已創建.bat文件: {bat_file_path}")
time.sleep(1)