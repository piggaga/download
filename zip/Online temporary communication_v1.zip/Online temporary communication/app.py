from flask import Flask, render_template, request, redirect, url_for, jsonify

app = Flask(__name__)
messages = []

@app.route('/', methods=['GET', 'POST'])
def index():
    global messages
    if request.method == 'POST':
        message = request.form['message']
        messages.append(message)
        return redirect(url_for('index'))
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(messages=messages)
    else:
        return render_template('index.html', messages=messages)

@app.route('/delete/<int:index>')
def delete_message(index):
    global messages
    if 0 <= index < len(messages):
        del messages[index]
    
    return redirect(url_for('index'))

@app.route('/download')
def download_messages():
    global messages
    return jsonify(messages=messages)

@app.route('/upload', methods=['POST'])
def upload_messages():
    global messages
    data = request.json
    if 'messages' in data:
        messages.extend(data['messages'])
    return jsonify({'message': 'Upload successful'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=11545)
