from flask import Flask, render_template, request, jsonify
import subprocess
import socket
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

history = {}  # Dictionary to store history

# Function to install dependencies from requirements.txt

# Install dependencies if requirements.txt is present


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/run', methods=['POST'])
def run_code():
    try:
        code = request.form['code']
        user_ip = request.remote_addr.replace('.', '_')
        temp_filename = f'{user_ip}_temp.py'

        # Write the code to a temporary file
        with open(temp_filename, 'w') as f:
            f.write(code)

        try:
            # Execute the code and capture output and errors
            result = subprocess.run(['python', temp_filename], capture_output=True, text=True, timeout=10)
            output = result.stdout
            error = result.stderr
            if result.returncode != 0:
                raise subprocess.CalledProcessError(result.returncode, 'python', output=output, stderr=error)
        except subprocess.CalledProcessError as e:
            error = e.stderr if e.stderr else str(e)
            return jsonify({'output': '', 'error': error})
        except subprocess.TimeoutExpired:
            error = "Execution timed out (5 seconds)"
            return jsonify({'output': '', 'error': error})
        except Exception as e:
            error = str(e)
            return jsonify({'output': '', 'error': error})
        finally:
            try:
                os.remove(temp_filename)
            except Exception as e:
                print(f"Failed to delete temp file: {e}")

        # Save to history
        if user_ip not in history:
            history[user_ip] = []
        history[user_ip].append({'code': code, 'output': output, 'error': error})

        return jsonify({'output': output, 'error': ''})
    except Exception as e:
        return jsonify({'output': '', 'error': f"An unexpected error occurred: {str(e)}"})

@app.route('/history', methods=['GET'])
def get_history():
    user_ip = request.remote_addr.replace('.', '_')
    user_history = history.get(user_ip, [])
    return jsonify({'history': user_history})

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'output': '', 'error': 'No file part'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'output': '', 'error': 'No selected file'})
        
        user_ip = request.remote_addr.replace('.', '_')
        temp_filename = f'{user_ip}_temp.py'
        
        file.save(temp_filename)

        try:
            # Execute the code and capture output and errors
            result = subprocess.run(['python', temp_filename], capture_output=True, text=True, timeout=5)
            output = result.stdout
            error = result.stderr
            if result.returncode != 0:
                raise subprocess.CalledProcessError(result.returncode, 'python', output=output, stderr=error)
        except subprocess.CalledProcessError as e:
            error = e.stderr if e.stderr else str(e)
            return jsonify({'output': '', 'error': error})
        except subprocess.TimeoutExpired:
            error = "Execution timed out (5 seconds)"
            return jsonify({'output': '', 'error': error})
        except Exception as e:
            error = str(e)
            return jsonify({'output': '', 'error': error})
        finally:
            try:
                os.remove(temp_filename)
            except Exception as e:
                print(f"Failed to delete temp file: {e}")

        # Save to history
        if user_ip not in history:
            history[user_ip] = []
        history[user_ip].append({'code': file.read(), 'output': output, 'error': error})

        return jsonify({'output': output, 'error': ''})
    except Exception as e:
        return jsonify({'output': '', 'error': f"An unexpected error occurred: {str(e)}"})

def get_local_ip():
    # Get the local IP address of the running device
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))  # Try to connect to a nonexistent IP
        local_ip = s.getsockname()[0]
    except Exception as e:
        print(f"Failed to get local IP: {e}")
        local_ip = '127.0.0.1'
    finally:
        s.close()
    return local_ip

# Determine the IP address and construct the URL
host_ip = get_local_ip()

# Run the Flask app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=7777, debug=False)
